/*
================
Array Pagar Prima
================

[INSTRUCTIONS]

arrayPagarPrima adalah sebuah function yang menerima satu parameter berupa array multidimensi.
function akan mereturn array multidimensi dengan merubah angka prima menjadi pagar.
Jika tidak input, maka function akan mereturn 'tidak ada array'

[EXAMPLE]
arrayPagarPrima([
  [5, 7, 10],
  [8, 2, 3],
  [44, 50, 22]
])

output:
[
  ['#', '#', 10],
  [8, '#', '#'],
  [44, 50, 22]
]

RULES:
  - DILARANG menambahkan parameter baru
  - DILARANG menggunakan built in function .indexOf, .include, .findIndex, .reduce, .map, .filter
  - DILARANG menggunakan REGEX
*/
function arrayPagarPrima(angka) { 
  
}

console.log(arrayPagarPrima([[5, 7, 10], [8, 2, 3], [44, 50, 22]]));

/*
[
  ['#', '#', 10],
  [8, '#', '#'],
  [44, 50, 22]
]
*/

console.log(arrayPagarPrima([
  [2, 3, 5],
  [7, 11, 13],
  [17, 19, 23]
]));

/*
[
  ['#', '#', '#'],
  ['#', '#', '#'],
  ['#', '#', '#']
]
*/

console.log(arrayPagarPrima([
  [12, 30, 50],
  [70, 10, 30],
  [10, 10, 20]
]));

/*
[
  [12, 30, 50],
  [70, 10, 30],
  [10, 10, 20]
]
 */

 console.log(arrayPagarPrima([]));

// // // 'tidak ada array'

