/*
  Buatlah sebuah algoritma atau pseudocode untuk kasus berikut:
  Suatu toko baju 'X' sedang mengadakan midnight sale dengan ketentuan sebagai berikut:
  - Jumlah baju yang dibeli lebih dari 9 maka akan mendapatkan 5 baju lagi
  - Jumlah baju yang dibeli lebih dari 5 maka akan mendapatkan 3 baju lagi
  - Jumlah baju yang dibeli lebih dari 2 maka akan mendapatkan 1 barang lagi
  Tampilkan jumlah baju yang didapatkan oleh pembeli.
  NOTED:
  Jika jumlah baju kurang dari 0 atau menerima input selain angka maka tampilkan 'Input Invalid'
*/
