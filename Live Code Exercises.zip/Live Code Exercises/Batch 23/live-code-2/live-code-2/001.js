/*
===================
Jumlah Huruf Vocal
===================
[INSTRUCTIONS]

SumVocal adalah sebuah function yang menerima satu parameter berupa array of string.
function akan mereturn sebuah nilai jumlah dari huruf vocal yang ada di array tersebut.
Jika tidak ada angka ganjil dalam array tersebut, maka function akan mereturn angka -1

[RULE]
- Wajib menuliskan pseudocode atau algorithma. Tidak ada pseudocode / pseudocode tidak match dengan kode maka indikasi soal tidak diselesaikan secara pribadi dan tidak akan dinilai.
- Dilarang menggunakan sintaks .split()! .findIndex .indexOf .filter .map
- Dilarang menggunakan regex .match, .replace dan lainnya!
- Asumsi input selalu upper case atau huruf besar
- Jika tidak ada huruf vocal maka function akan mengembalikan nilai -1
[EXAMPLE]
SumVocal('ABCDEFG')

output: 2
*/

function SumVocal(array) {
 
}

console.log(SumVocal("AIUEO")); // 5
console.log(SumVocal("HACKTIV8")); // 2
console.log(SumVocal("JAKARTA")); // 3
console.log(SumVocal("QWRTYP")); // -1
